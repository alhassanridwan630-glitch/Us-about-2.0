import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { db } from "@/lib/firebase-admin";
import { validate, makeId, makeToken, hashToken } from "@/lib/invitations";
import { limited } from "@/lib/ratelimit";

export async function POST(req: Request) {
  const ip = (req.headers.get("x-forwarded-for") || "unknown").split(",")[0].trim();
  if (limited(`c:${ip}`, 10)) return NextResponse.json({ error: "Too many invitations from this connection. Try again later." }, { status: 429 });
  let body: Record<string, unknown>;
  try { body = await req.json(); } catch { return NextResponse.json({ error: "Invalid request." }, { status: 400 }); }
  const v = validate(body);
  if (!v.ok) return NextResponse.json({ error: v.error }, { status: 400 });

  let firestore;
  try { firestore = db(); } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "The server isn’t connected to Firebase yet." }, { status: 503 });
  }
  const token = makeToken();
  for (let i = 0; i < 3; i++) {
    const id = makeId(v.data.recipientName);
    try {
      await firestore.collection("invitations").doc(id).create({
        ...v.data, status: "pending", opened: false, tokenHash: hashToken(token), createdAt: FieldValue.serverTimestamp(),
      });
      const site = process.env.NEXT_PUBLIC_SITE_URL || new URL(req.url).origin;
      return NextResponse.json({ id, url: `${site}/invite/${id}`, manageToken: token }, { status: 201 });
    } catch (e) {
      if ((e as { code?: number }).code !== 6) return NextResponse.json({ error: "Couldn’t save the invitation. Try again." }, { status: 500 });
    }
  }
  return NextResponse.json({ error: "Couldn’t create a unique link. Try again." }, { status: 500 });
}
