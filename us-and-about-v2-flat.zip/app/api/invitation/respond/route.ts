import { NextResponse } from "next/server";
import { FieldValue } from "firebase-admin/firestore";
import { db } from "@/lib/firebase-admin";
import { ID_RE } from "@/lib/invitations";
import { limited } from "@/lib/ratelimit";

const s = (v: unknown, max: number) => (typeof v === "string" ? v.trim().slice(0, max) : "");
const list = (v: unknown) => (Array.isArray(v) ? v.slice(0, 20).map((x) => s(x, 40)).filter(Boolean) : []);

export async function POST(req: Request) {
  let b: Record<string, unknown>;
  try { b = await req.json(); } catch { return NextResponse.json({ error: "Invalid request." }, { status: 400 }); }
  const id = s(b.id, 40);
  if (!ID_RE.test(id)) return NextResponse.json({ error: "Not found." }, { status: 404 });
  const ip = (req.headers.get("x-forwarded-for") || "unknown").split(",")[0].trim();
  if (limited(`r:${ip}`, 60)) return NextResponse.json({ error: "Too many requests. Try again later." }, { status: 429 });

  let ref;
  try { ref = db().collection("invitations").doc(id); } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "Server not configured." }, { status: 503 });
  }
  const snap = await ref.get();
  if (!snap.exists) return NextResponse.json({ error: "Not found." }, { status: 404 });
  const now = FieldValue.serverTimestamp();

  switch (b.type) {
    case "open": if (!snap.data()!.opened) await ref.update({ opened: true, openedAt: now }); break;
    case "accept": await ref.update({ status: "accepted", respondedAt: now }); break;
    case "decline": await ref.update({ status: "declined", respondedAt: now }); break;
    case "plan": {
      const p = (b.plan ?? {}) as Record<string, unknown>;
      const date = s(p.date, 10);
      if (date !== "surprise" && (!/^\d{4}-\d{2}-\d{2}$/.test(date) || new Date(date + "T00:00:00Z").getTime() < Date.now() - 1.5 * 864e5))
        return NextResponse.json({ error: "Pick today or a future date." }, { status: 400 });
      const t = (p.time ?? {}) as Record<string, unknown>;
      const h = s(t.h, 5);
      if (h && !/^\d{2}:\d{2}$/.test(h)) return NextResponse.json({ error: "Invalid time." }, { status: 400 });
      const plan = { date, time: { h, l: s(t.l, 20) }, doing: list(p.doing), after: list(p.after), vibe: s(p.vibe, 40), where: s(p.where, 120), notes: s(p.notes, 300) };
      if (!plan.doing.length || !plan.time.l) return NextResponse.json({ error: "Plan is incomplete." }, { status: 400 });
      await ref.update({ status: "accepted", plan, respondedAt: now, planSubmittedAt: now });
      break;
    }
    case "rsvp": {
      const guests = Number(b.guests);
      if (!Number.isInteger(guests) || guests < 1 || guests > 20) return NextResponse.json({ error: "Invalid guest count." }, { status: 400 });
      await ref.update({ status: "accepted", rsvp: { guests, notes: s(b.notes, 300) }, respondedAt: now, planSubmittedAt: now });
      break;
    }
    default: return NextResponse.json({ error: "Invalid request." }, { status: 400 });
  }
  return NextResponse.json({ ok: true });
}
