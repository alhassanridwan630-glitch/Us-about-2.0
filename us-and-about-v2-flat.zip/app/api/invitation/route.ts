import { NextResponse } from "next/server";
import { db } from "@/lib/firebase-admin";
import { ID_RE } from "@/lib/invitations";

// Public read: only what a recipient needs. Never returns tokenHash or response data.
export async function GET(req: Request) {
  const id = new URL(req.url).searchParams.get("id") || "";
  if (!ID_RE.test(id)) return NextResponse.json({ error: "Not found." }, { status: 404 });
  let snap;
  try { snap = await db().collection("invitations").doc(id).get(); } catch (e) {
    return NextResponse.json({ error: e instanceof Error ? e.message : "Server not configured." }, { status: 503 });
  }
  if (!snap.exists) return NextResponse.json({ error: "Not found." }, { status: 404 });
  const d = snap.data()!;
  return NextResponse.json({
    creatorName: d.creatorName, recipientName: d.recipientName, occasion: d.occasion, customOccasion: d.customOccasion,
    message: d.message, note: d.note, theme: d.theme, music: d.music, welcomeMessage: d.welcomeMessage,
    preferredDate: d.preferredDate, instructions: d.instructions, status: d.status,
    eventTime: d.eventTime ?? "", eventLocation: d.eventLocation ?? "",
  });
}
