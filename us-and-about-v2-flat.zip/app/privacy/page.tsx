import type { Metadata } from "next";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { SUPPORT_EMAIL } from "@/lib/site";
export const metadata: Metadata = { title: "Privacy · US&ABOUT" };
const P = ({ t, children }: { t: string; children: React.ReactNode }) => <><h2 className="mt-6 font-display text-2xl">{t}</h2><p className="mt-2 text-lavender">{children}</p></>;
export default function Page() {
  return (<><SiteHeader /><main className="mx-auto max-w-xl px-4 pb-16 pt-8"><h1 className="font-display text-4xl">Privacy</h1>
    <P t="What we store">Names, your message, the theme and options you choose, and the recipient’s answer and plan. We don’t ask anyone to create an account.</P>
    <P t="Who can see it">Anyone with an invitation link can open that invitation. Only someone with your private link or code can see the response.</P>
    <P t="Deleting">Open your private link and choose Delete. The invitation and its response are erased and the link stops working.</P>
    <P t="Contact">Questions? Email <a className="underline" href={`mailto:${SUPPORT_EMAIL}`}>{SUPPORT_EMAIL}</a>.</P></main><SiteFooter /></>);
}
