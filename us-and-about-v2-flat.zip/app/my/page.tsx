import type { Metadata } from "next";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import MyInvitations from "@/components/MyInvitations";
export const metadata: Metadata = { title: "My invitations · US&ABOUT", robots: { index: false } };
export default function Page() { return <><SiteHeader /><MyInvitations /><SiteFooter /></>; }
