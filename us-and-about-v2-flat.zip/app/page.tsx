import { SiteHeader } from "@/components/SiteHeader";
import { Button } from "@/components/Button";
import { FloatingHearts } from "@/components/FloatingHearts";
import { InvitationCard } from "@/components/InvitationCard";
import { HomeSections } from "@/components/HomeSections";

export default function Home() {
  return (
    <>
      <SiteHeader />
      <main className="relative overflow-x-clip">
        <FloatingHearts />
        <section className="relative z-10 mx-auto grid max-w-6xl items-center gap-12 px-5 pb-16 pt-10 md:grid-cols-2 md:pt-20">
          <div>
            <h1 className="font-display text-5xl leading-[1.05] sm:text-6xl lg:text-7xl">Some moments deserve an invitation.</h1>
            <p className="mt-6 max-w-md text-lg leading-relaxed text-lavender">Create something special. Invite someone you love. Make a memory together.</p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row">
              <Button href="/create">Create an invitation</Button>
              <Button href="/#how-it-works" variant="ghost">See how it works</Button>
            </div>
          </div>
          <InvitationCard />
        </section>
        <HomeSections />
      </main>
    </>
  );
}
