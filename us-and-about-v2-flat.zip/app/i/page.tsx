import type { Metadata } from "next";
import Recipient from "@/components/Recipient";

export const metadata: Metadata = { title: "You’ve got an invitation · US&ABOUT", robots: { index: false, follow: false } };

export default async function Page({ searchParams }: { searchParams: Promise<{ id?: string; preview?: string }> }) {
  const { id = "", preview } = await searchParams;
  return <Recipient id={id} noSave={preview === "1"} />;
}
