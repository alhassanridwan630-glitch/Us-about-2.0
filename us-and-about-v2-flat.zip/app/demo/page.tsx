import type { Metadata } from "next";
import Recipient from "@/components/Recipient";
import type { Draft } from "@/lib/invitations";

export const metadata: Metadata = { title: "Demo · US&ABOUT", robots: { index: false } };
type Inv = Draft & { status: string };
const base: Inv = { creatorName: "", recipientName: "", occasion: "", customOccasion: "", message: "", note: "", theme: "", music: false, welcomeMessage: "", preferredDate: "", instructions: "", eventTime: "", eventLocation: "", status: "pending" };

export default async function Page({ searchParams }: { searchParams: Promise<{ k?: string }> }) {
  const { k = "romantic" } = await searchParams;
  const sun = new Date(); sun.setDate(sun.getDate() + (7 - sun.getDay() || 7));
  const demos: Record<string, Inv> = {
    romantic: { ...base, creatorName: "Alex", recipientName: "Faith", occasion: "first-date", theme: "midnight-romance", message: "Would you do me the honour of going on a date with me?" },
    friends: { ...base, creatorName: "Jo", recipientName: "Sam", occasion: "birthday", theme: "confetti", message: "I’ve got something special planned for your birthday. Clear your schedule?" },
    church: { ...base, creatorName: "Pastor Ife", recipientName: "Brother David", occasion: "church", theme: "golden-hour", message: "You’re warmly invited to our youth program. Come and be blessed.", preferredDate: sun.toISOString().slice(0, 10), eventTime: "16:00", eventLocation: "Main auditorium" },
  };
  return <Recipient id="demo" demo={demos[k] ?? demos.romantic} />;
}
