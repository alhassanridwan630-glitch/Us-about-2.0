"use client";
import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, Copy, Check, MessageCircle, Eye, LayoutDashboard } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { OCCASIONS, THEMES, SUGGESTIONS, emptyDraft, kindOf, type Draft } from "@/lib/invitations";
import { loadDraft, saveDraft, clearDraft, rememberInvitation } from "@/lib/local";

const STEPS = ["Who", "Occasion", "Message", "Theme", "Details", "Preview"];
const DEFAULT_THEME = { romantic: "midnight-romance", casual: "confetti", formal: "elegant-cream" } as const;
const SYMBOL = { romantic: "♥ ♥ ♥", casual: "★ ★ ★", formal: "✦ ✦ ✦" } as const;
const input = "mt-2 w-full rounded-xl border border-burgundy/30 bg-white/60 px-4 py-3 text-burgundy placeholder:text-burgundy/40";
const btn = "inline-flex min-h-12 items-center justify-center rounded-full px-7 text-sm font-semibold transition active:scale-[.97] disabled:opacity-50";
const nice = (i: string) => new Date(i + "T00:00").toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" });

function Preview({ d }: { d: Draft }) {
  const t = THEMES.find((x) => x.id === d.theme) ?? THEMES[0];
  const k = kindOf(d.occasion || "custom");
  const when = [d.preferredDate && nice(d.preferredDate), d.eventTime, d.eventLocation].filter(Boolean).join(" · ");
  return (
    <div className="rounded-2xl p-6 text-center shadow-glow" style={{ background: t.bg, color: t.fg }}>
      <p className="text-xs tracking-[.4em]" style={{ color: t.accent }}>{SYMBOL[k]}</p>
      {d.welcomeMessage && <p className="mt-2 text-sm opacity-80">{d.welcomeMessage}</p>}
      <p className="mt-2 font-script text-4xl" style={{ color: t.accent }}>{k === "formal" ? `${d.recipientName || "Friend"}, you’re invited` : `Hey ${d.recipientName || "you"}!`}</p>
      <p className="mt-2 font-display text-2xl leading-snug">{d.message || "Your message appears here."}</p>
      {d.note && <p className="mt-3 text-sm italic opacity-80">{d.note}</p>}
      {k === "formal" && when && <p className="mt-3 text-sm opacity-80">{when}</p>}
      <div className="mt-5 flex justify-center gap-3 text-sm font-semibold">
        <span className="rounded-full px-5 py-2" style={{ background: t.accent, color: t.bg }}>{k === "formal" ? "Yes, I’ll be there" : "Yes"}</span>
        <span className="rounded-full border px-5 py-2" style={{ borderColor: t.fg + "66" }}>{k === "formal" ? "Can’t make it" : "No"}</span>
      </div>
      <p className="mt-4 font-script text-2xl" style={{ color: t.accent }}>— {d.creatorName || "you"}</p>
    </div>
  );
}

export default function Create() {
  const [d, setD] = useState<Draft>(emptyDraft);
  const [step, setStep] = useState(0);
  const [err, setErr] = useState(""); const [busy, setBusy] = useState(false); const [ready, setReady] = useState(false);
  const [done, setDone] = useState<{ id: string; url: string; token: string; manage: string } | null>(null);
  const [copied, setCopied] = useState(""); const touched = useRef(false);
  const set = <K extends keyof Draft>(k: K, v: Draft[K]) => { setD((p) => ({ ...p, [k]: v })); setErr(""); };
  const kind = kindOf(d.occasion || "custom");

  useEffect(() => {
    const q = new URLSearchParams(location.search);
    if (q.get("draft") === "1") { const s = loadDraft(); if (s) { setD({ ...emptyDraft, ...(s.d as Partial<Draft>) }); setStep(Math.min(s.step, 5)); touched.current = true; } }
    const o = q.get("occasion");
    if (o && OCCASIONS.some((x) => x.id === o)) setD((p) => ({ ...p, occasion: o, theme: DEFAULT_THEME[kindOf(o)] }));
    setReady(true);
  }, []);
  useEffect(() => { if (ready && !done && (d.creatorName || d.recipientName || d.message)) saveDraft(d, step); }, [d, step, ready, done]); // autosave

  const pickOcc = (id: string) => { setErr(""); setD((p) => ({ ...p, occasion: id, theme: touched.current ? p.theme : DEFAULT_THEME[kindOf(id)], message: Object.values(SUGGESTIONS).flat().includes(p.message) ? "" : p.message })); };
  const startOver = () => { if (!confirm("Start over? Your current draft will be cleared.")) return; clearDraft(); setD(emptyDraft); setStep(0); setErr(""); touched.current = false; };

  const problem = () => {
    if (step === 0 && (!d.creatorName.trim() || !d.recipientName.trim())) return "Add your name and theirs.";
    if (step === 1 && !d.occasion) return "Choose an occasion.";
    if (step === 1 && d.occasion === "custom" && !d.customOccasion.trim()) return "Describe your occasion.";
    if (step === 2 && !d.message.trim()) return "Write or pick a message.";
    if (step === 4 && kind === "formal" && !d.preferredDate) return "Add the event date.";
    if (step === 4 && kind === "formal" && !d.eventLocation.trim()) return "Add the event location.";
    return "";
  };
  const next = () => { const p = problem(); if (p) return setErr(p); setStep((s) => s + 1); };

  const publish = async () => {
    setBusy(true); setErr("");
    try {
      const r = await fetch("/api/invitations", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(d) });
      const j = await r.json();
      if (!r.ok) throw new Error(j.error || "Something went wrong.");
      try { localStorage.setItem(`usabout:manage:${j.id}`, j.manageToken); } catch {}
      rememberInvitation({ id: j.id, name: d.recipientName, occasion: d.occasion, at: new Date().toISOString() }); clearDraft();
      setDone({ id: j.id, url: j.url, token: j.manageToken, manage: `${location.origin}/manage/${j.id}#${j.manageToken}` });
    } catch (e) { setErr(e instanceof Error ? e.message : "Something went wrong."); }
    setBusy(false);
  };
  const copy = async (k: string, v: string) => { try { await navigator.clipboard.writeText(v); setCopied(k); setTimeout(() => setCopied(""), 1500); } catch { setErr("Couldn’t copy. Select the text instead."); } };

  const sugg = SUGGESTIONS[d.occasion] ?? SUGGESTIONS.default;
  const themes = [...THEMES].sort((a, b) => Number((b.kinds as readonly string[]).includes(kind)) - Number((a.kinds as readonly string[]).includes(kind)));
  const wa = done ? `https://wa.me/?text=${encodeURIComponent(`${kind === "formal" ? "You’re invited" : "I made something for you"}: ${done.url}`)}` : "#";

  return (<>
    <SiteHeader />
    <main className="mx-auto min-h-screen max-w-xl px-4 pb-16 pt-6">
      {done ? (
        <div className="rounded-2xl bg-cream p-6 text-burgundy">
          <p className="font-script text-4xl text-rose">Your invitation is ready.</p>
          <p className="mt-2 break-all rounded-xl bg-burgundy/10 p-3 text-sm">{done.url}</p>
          <div className="mt-4 flex flex-wrap gap-3">
            <button className={`${btn} bg-burgundy text-cream`} onClick={() => copy("link", done.url)}>{copied === "link" ? <Check size={16} /> : <Copy size={16} />}&nbsp;Copy link</button>
            <a className={`${btn} bg-rose text-midnight`} href={wa} target="_blank" rel="noopener noreferrer"><MessageCircle size={16} />&nbsp;WhatsApp</a>
            <a className={`${btn} border border-burgundy/40`} href={`/invite/${done.id}?preview=1`}><Eye size={16} />&nbsp;Preview</a>
          </div>
          <div className="mt-6 rounded-xl border border-rose/50 p-4 text-sm">
            <p className="font-semibold">Your private dashboard</p>
            <p className="mt-1">This is where you see their answer and plan, and where you can delete the invitation. Keep the link and code to yourself. The code is shown only now.</p>
            <div className="mt-3 flex flex-wrap gap-3">
              <a className={`${btn} bg-burgundy text-cream`} href={done.manage}><LayoutDashboard size={16} />&nbsp;Open dashboard</a>
              <button className={`${btn} border border-burgundy/40`} onClick={() => copy("manage", done.manage)}>{copied === "manage" ? "Copied" : "Copy private link"}</button>
            </div>
            <p className="mt-4">Private code</p>
            <p className="mt-1 break-all rounded-lg bg-burgundy/10 p-2 font-mono text-xs">{done.token}</p>
            <button className="mt-2 text-sm underline" onClick={() => copy("code", done.token)}>{copied === "code" ? "Copied" : "Copy code"}</button>
          </div>
          <div className="mt-6 flex flex-wrap gap-4 text-sm"><Link className="underline" href="/my">My invitations</Link><a className="underline" href="/create">Create another</a><Link className="underline" href="/">Home</Link></div>
        </div>
      ) : (
        <>
          <div className="mb-3 flex items-center justify-between text-sm text-lavender">
            <Link href="/" className="inline-flex min-h-11 items-center underline">← Exit to home</Link>
            <button className="min-h-11 underline" onClick={startOver}>Start over</button>
          </div>
          <div className="mb-4 flex gap-1.5" aria-hidden>{STEPS.map((_, i) => <i key={i} className={`h-1 flex-1 rounded ${i <= step ? "bg-rose" : "bg-cream/15"}`} />)}</div>
          <AnimatePresence mode="wait">
            <motion.section key={step} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.25 }} className="rounded-2xl bg-cream p-6 text-burgundy">
              <p className="text-sm text-burgundy/70">Step {step + 1} of {STEPS.length}: {STEPS[step]}</p>
              {step === 0 && <>
                <h1 className="mt-1 font-display text-3xl">Who are you inviting?</h1>
                <label className="mt-4 block text-sm">Your name<input className={input} maxLength={30} value={d.creatorName} onChange={(e) => set("creatorName", e.target.value)} /></label>
                <label className="mt-3 block text-sm">Their name<input className={input} maxLength={30} value={d.recipientName} onChange={(e) => set("recipientName", e.target.value)} /></label>
              </>}
              {step === 1 && <>
                <h1 className="mt-1 font-display text-3xl">What’s the occasion?</h1>
                <div className="mt-4 grid grid-cols-2 gap-2">{OCCASIONS.map((o) => (
                  <button key={o.id} aria-pressed={d.occasion === o.id} onClick={() => pickOcc(o.id)}
                    className={`min-h-14 rounded-xl border px-3 text-sm ${d.occasion === o.id ? "border-burgundy bg-burgundy text-cream" : "border-burgundy/30"}`}>{o.label}</button>))}</div>
                {d.occasion === "custom" && <input className={input} maxLength={40} placeholder="e.g. Graduation lunch" value={d.customOccasion} onChange={(e) => set("customOccasion", e.target.value)} />}
              </>}
              {step === 2 && <>
                <h1 className="mt-1 font-display text-3xl">Say it your way.</h1>
                <div className="mt-3 flex flex-col gap-2">{sugg.map((s) => (
                  <button key={s} onClick={() => set("message", s)} className="rounded-xl border border-burgundy/30 px-3 py-2 text-left text-sm hover:border-rose">{s}</button>))}</div>
                <label className="mt-4 block text-sm">Your invitation message<textarea className={input} rows={3} maxLength={300} value={d.message} onChange={(e) => set("message", e.target.value)} /></label>
                <label className="mt-3 block text-sm">Personal note (optional)<textarea className={input} rows={2} maxLength={300} value={d.note} onChange={(e) => set("note", e.target.value)} /></label>
              </>}
              {step === 3 && <>
                <h1 className="mt-1 font-display text-3xl">Pick a theme.</h1>
                <p className="text-sm text-burgundy/70">Recommended themes for this occasion come first.</p>
                <div className="mt-4 grid grid-cols-2 gap-3">{themes.map((t) => (
                  <button key={t.id} aria-pressed={d.theme === t.id} onClick={() => { touched.current = true; set("theme", t.id); }}
                    className={`rounded-xl p-4 text-left text-sm ring-offset-2 ${d.theme === t.id ? "ring-2 ring-rose" : ""}`} style={{ background: t.bg, color: t.fg }}>
                    <span className="font-script text-2xl" style={{ color: t.accent }}>Aa</span><br />{t.name}
                    {(t.kinds as readonly string[]).includes(kind) && <span className="mt-1 block text-[11px] opacity-80">Recommended</span>}</button>))}</div>
              </>}
              {step === 4 && <>
                <h1 className="mt-1 font-display text-3xl">{kind === "formal" ? "Event details." : "Optional extras."}</h1>
                <label className="mt-4 block text-sm">{kind === "formal" ? "Event date" : "Preferred date (optional)"}<input type="date" className={input} min={new Date().toISOString().slice(0, 10)} value={d.preferredDate} onChange={(e) => set("preferredDate", e.target.value)} /></label>
                {kind === "formal" && <>
                  <label className="mt-3 block text-sm">Start time (optional)<input type="time" className={input} value={d.eventTime} onChange={(e) => set("eventTime", e.target.value)} /></label>
                  <label className="mt-3 block text-sm">Venue or address<input className={input} maxLength={120} value={d.eventLocation} onChange={(e) => set("eventLocation", e.target.value)} /></label></>}
                <label className="mt-3 block text-sm">Welcome message (optional)<input className={input} maxLength={120} value={d.welcomeMessage} onChange={(e) => set("welcomeMessage", e.target.value)} /></label>
                <label className="mt-3 block text-sm">Special instructions (optional)<textarea className={input} rows={2} maxLength={300} value={d.instructions} onChange={(e) => set("instructions", e.target.value)} /></label>
                <label className="mt-3 flex items-center gap-2 text-sm"><input type="checkbox" checked={d.music} onChange={(e) => set("music", e.target.checked)} />Play soft background music</label>
              </>}
              {step === 5 && <>
                <h1 className="mt-1 font-display text-3xl">Here’s what they’ll see.</h1>
                <div className="mt-4"><Preview d={d} /></div>
                <p className="mt-3 text-sm">You can go back and edit anything before you create the link.</p>
              </>}
              <p role="alert" className="mt-3 min-h-5 text-sm text-[#b3123f]">{err}</p>
              <div className="mt-2 flex flex-wrap items-center gap-3">
                {step > 0 && <button className={`${btn} border border-burgundy/40`} onClick={() => setStep(step - 1)}><ArrowLeft size={16} />&nbsp;Back</button>}
                {step < 5 ? <button className={`${btn} bg-burgundy text-cream`} onClick={next}>Continue</button>
                  : <button className={`${btn} bg-rose text-midnight`} disabled={busy} onClick={publish}>{busy ? "Creating…" : "Generate invitation link"}</button>}
                <button className="min-h-11 text-sm underline" onClick={() => { saveDraft(d, step); setCopied("draft"); setTimeout(() => setCopied(""), 2500); }}>{copied === "draft" ? "Draft saved" : "Save draft"}</button>
              </div>
              <p className="mt-3 text-xs text-burgundy/70">Your progress saves automatically. Find it in <Link className="underline" href="/my">My invitations</Link>.</p>
            </motion.section>
          </AnimatePresence>
        </>
      )}
    </main>
    <SiteFooter />
  </>);
}
