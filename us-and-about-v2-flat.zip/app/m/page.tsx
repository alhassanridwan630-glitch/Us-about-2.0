import type { Metadata } from "next";
import Manage from "@/components/Manage";

export const metadata: Metadata = { title: "Your invitation · US&ABOUT", robots: { index: false, follow: false } };

export default async function Page({ searchParams }: { searchParams: Promise<{ id?: string }> }) {
  const { id = "" } = await searchParams;
  return <Manage id={id} />;
}
